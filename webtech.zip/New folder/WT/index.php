<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h3>Personal Information</h3>

	<form action="additional.php" method="get">
		<table>
			<tr>
				<td>FULL NAME: </td>
				<td><input type="text"></td>
			</tr>
			<tr>
				<td>EMAIL: </td>
				<td><input type="text"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Next"></td>
			</tr>
		</table>
	</form>
</body>
</html>