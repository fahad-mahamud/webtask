<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h3>Preview Information</h3>
	<form action="form.php" method="get">

	<table>
		<tr>
			<td>FULL NAME: </td>
			<td>Some Name</td>
		</tr>
		<tr>
			<td>EMAIL: </td>
			<td>Some Email</td>
		</tr>
		<tr>
			<td>DATE OF BIRTH: </td>
			<td>Some DOB</td>
		</tr>
		<tr>
			<td>GENDER: </td>
			<td>Some Gender</td>
		</tr>
		<tr>
			<td>USERNAME: </td>
			<td>Some Username</td>
		</tr>
		<tr>
			<td>PASSWORD: </td>
			<td>****</td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" value="Confirm"></td>
		</tr>
	</table>
</body>
</html>