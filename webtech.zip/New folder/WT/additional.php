<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h3>Additional Information</h3>

	<form action="preview.php" method="get">
		<table>
			<tr>
				<td>DATE OF BIRTH: </td>
				<td><input type="text"></td>
			</tr>
			<tr>
				<td>GENDER: </td>
				<td>
					<select>
						<option>Male</option>
						<option>Female</option>
					</select>
				</td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Next"></td>
			</tr>
		</table>
	</form>
</body>
</html>