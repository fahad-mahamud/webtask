<?php
	require_once('db.php');
	
	if(isset($_POST['btnSubmit']))
	{
		//DELETE
		$sql = "DELETE FROM departments WHERE dept_id=$_POST[did]";
		echo mysqli_query($sql);
		header('Location: dept-list.php');
		return;
	}
	// SELECT
	$sql = "SELECT * FROM departments WHERE dept_id=$_GET[did]";
	$result = mysqli_query($sql);
	$row = mysqli_fetch_assoc($result);
	if(!$row)
	{
		echo 'Department does not exist';
		return;
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>Delete Department</h2>
	<a href="dept-list.php">Back</a>
	<br/><br/>
	<h3>Are you sure to delete the following department?</h3>
	<form method="post">
		<input type="hidden" name="did" value="<?php echo $row['dept_id']; ?>">
		<table>
			<tr>
				<td>NAME</td>
				<td><?php echo $row['dept_name']; ?></td>
			</tr>
			<tr>
				<td>LOCATION</td>
				<td><?php echo $row['location']; ?></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="btnSubmit" value="Delete" /></td>
			</tr>
		</table>
	</form>
</body>
</html>