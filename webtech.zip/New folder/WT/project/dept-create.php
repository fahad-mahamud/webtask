<?php
	if(isset($_POST['btnSubmit']))
	{
		require_once('db.php');

		//INSERT
		$sql = "INSERT INTO departments VALUES (null, '$_POST[dname]', '$_POST[loc]')";
		mysqli_query($sql);
		//echo 'Department created successfully';
		header('Location: dept-list.php');
		return;
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>Create Department</h2>
	<a href="dept-list.php">Back</a>
	<br/><br/>
	<form method="post">
		<table>
			<tr>
				<td>NAME</td>
				<td><input type="text" name="dname" /></td>
			</tr>
			<tr>
				<td>LOCATION</td>
				<td><input type="text" name="loc" /></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="btnSubmit" value="Create" /></td>
			</tr>
		</table>
	</form>
</body>
</html>