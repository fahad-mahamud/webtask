<?php
	require_once('db.php');
	
	if(isset($_POST['btnSubmit']))
	{
		//UPDATE
		$sql = "UPDATE departments SET dept_name='$_POST[dname]', location='$_POST[loc]' WHERE dept_id=$_POST[did]";
		echo mysqli_query($sql);
		header('Location: dept-list.php');
		return;
	}
	// SELECT
	$sql = "SELECT * FROM departments WHERE dept_id=$_GET[did]";
	$result = mysqli_query($sql);
	$row = mysqli_fetch_assoc($result);
	if(!$row)
	{
		echo 'Department does not exist';
		return;
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>Edit Department</h2>
	<a href="dept-list.php">Back</a>
	<br/><br/>
	<form method="post">
		<input type="hidden" name="did" value="<?php echo $row['dept_id']; ?>">
		<table>
			<tr>
				<td>NAME</td>
				<td><input type="text" name="dname" value="<?php echo $row['dept_name']; ?>" /></td>
			</tr>
			<tr>
				<td>LOCATION</td>
				<td><input type="text" name="loc" value="<?php echo $row['location']; ?>" /></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="btnSubmit" value="Update" /></td>
			</tr>
		</table>
	</form>
</body>
</html>