<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<a href="dept-list.php">Departments</a> | <a href="#">Employees</a>
</body>
</html>