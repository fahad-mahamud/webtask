<?php
	require_once('db.php');
	
	
	// SELECT
	$sql = "SELECT * FROM departments";
	$result = mysql_query($sql);
	$output = '';
	while($row = mysql_fetch_assoc($result))
	{
		$output .= '<tr>';
		$output .= "<td>$row[dept_id]</td>";
		$output .= "<td>$row[dept_name]</td>";
		$output .= "<td>$row[location]</td>";
		$output .= "<td><a href='dept-edit.php?did=$row[dept_id]'>Edit</a> | <a href='dept-delete.php?did=$row[dept_id]'>Delete</a></td>";
		$output .= '</tr>';
	}
	
	/*
	//INSERT
	$sql = "INSERT INTO departments VALUES (null, 'IT', 'Beijing'), (null, 'Distribution', 'Delhi')";
	echo mysql_query($sql);
	*/

	/*
	//UPDATE
	$sql = "UPDATE departments SET location='Colombo' WHERE dept_id=2";
	echo mysql_query($sql);
	*/

	/*
	//DELETE
	$sql = "DELETE FROM departments WHERE dept_id=2";
	echo mysql_query($sql);
	*/

	mysql_close($con);

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>Department List</h2>
	<a href="dept-create.php">Create New</a>
	<br/><br/>
	<table border="1">
		<tr>
			<th>ID</th>
			<th>NAME</th>
			<th>LOCATION</th>
			<th>OPTIONS</th>
		</tr>
		<?php
			/*while($row = mysql_fetch_assoc($result))
			{
				echo '<tr>';
				echo "<td>$row[dept_id]</td>";
				echo "<td>$row[dept_name]</td>";
				echo "<td>$row[location]</td>";
				echo '</tr>';
			}*/
		?>
		<?php echo $output; ?>
	</table>
</body>
</html>