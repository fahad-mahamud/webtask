<?php
	$fp=fopen('hello.txt','a');
	fwrite($fp,"this is fucking bullshit");
	fclose($fp);
?>