<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h3>Error</h3>
	<p>Oops! something unexpected happened</p>
	
	<!-- Optional Paragraph -->
	<p>Error Message: Some error message</p>
	
	<p>Click <a href="#">here</a> to start over</p>
</body>
</html>