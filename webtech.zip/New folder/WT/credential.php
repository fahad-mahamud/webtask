<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h3>Account Credentials</h3>

	<form action="preview.php" method ="get">
		<table>
			<tr>
				<td>USERNAME: </td>
				<td><input type="text" name ="NAME"></td>
			</tr>
			<tr>
				<td>PASSWORD: </td>
				<td><input type="password" password ="PASSWORD"></td>
			</tr>
			<tr>
				<td>CONFIRM: </td>
				<td><input type="password" password ="PASSWORD"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Preview"></td>
			</tr>
		</table>
	</form>
</body>
</html>